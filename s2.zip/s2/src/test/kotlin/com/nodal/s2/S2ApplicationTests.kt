package com.nodal.s2

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class S2ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
